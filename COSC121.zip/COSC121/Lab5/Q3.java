
/*
 * Using a Scanner to store user input, the user-given word is changed to lowercase to match the character given.
 * If the length of the string is 1, the count method will return without calling itself again. 
 * If the length of the string is greater than 1 and the character at index 0 matches the argument given, the method will return 1 and call itself again.
 * If the length of the string is greater than 1 and the character at index 0 does not match the argument given, the method will return 0 and call itself. 
 */

import java.util.Scanner;

public class Q3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Please enter a word: ");
		String word = in.next();
		System.out.println("Please enter a letter: ");
		char letter = in.next().charAt(0);
		System.out.println(
				"The letter " + Character.toString(letter) + " appears " + count(word, letter) + " times in " + word);
	}

	public static int count(String str, char a) {
		str = str.toLowerCase();
		if (str.length() > 1) {
			if (str.charAt(0) == a) {
				return 1 + count(str.substring(1), a);
			} else {
				return 0 + count(str.substring(1), a);
			}
		} else {
			if (str.equals(Character.toString(a))) {
				return 1;
			} else {
				return 0;
			}
		}
	}

}