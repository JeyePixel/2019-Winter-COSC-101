
/*
 * The method reverse() will take in a String as an argument. If the length of the string is 1, it just returns the string.
 * If the length of the string is greater than 1, it will call itself in it's return call and pass a new string as an argument. 
 * It forms this new string by returning the last character in the string and shortening the string. 
 */

public class Q2 {

	public static void main(String[] args) {
		System.out.println(reverse("ocat"));
	}

	public static String reverse(String str) {
		if (str.length() == 1) {
			return str;
		} else {
			return Character.toString(str.charAt(str.length() - 1)) + reverse(str.substring(0, str.length() - 1));
		}
	}

}
