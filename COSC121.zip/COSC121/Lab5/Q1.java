
/*
 * The method f() will take in a double as an argument. If the double is 0, f() will return 0.
 * If the double is greater than 0, the method will return (1 / (2 * i)) where i is the double and call itself on i-1.
 */

public class Q1 {

	public static void main(String[] args) {
		System.out.printf("i = 1 f(i) = " + "%.2f" + "\n", f(1));
		System.out.printf("i = 2 f(i) = " + "%.2f" + "\n", f(2));
		System.out.printf("i = 3 f(i) = " + "%.2f" + "\n", f(3));
		System.out.printf("i = 4 f(i) = " + "%.2f" + "\n", f(4));
		System.out.printf("i = 5 f(i) = " + "%.2f" + "\n", f(5));
	}

	public static double f(double i) {
		if (i > 0) {
			return (1 / (2 * i)) + f(i - 1);
		} else {
			return 0;
		}
	}

}
