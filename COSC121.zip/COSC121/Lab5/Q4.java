
/*
 * The listAllFiles method starts by determining if the filename it was passed belongs to a file or a directory.
 * If it belongs to a file, it prints the name. If it's a directory, it splits it into an array of files and calls the helper method on each element inside the array.
 * The helper will increment the number of spaces before a files name is printed, formatting the output in a cascading fashion. 
 */

import java.io.File;

public class Q4 {

	public static void main(String[] args) {
		File file = new File("C:\\Users\\Ian\\Desktop\\Folder 1");
		listAllFiles(file);

	}

	public static void listAllFiles(File dr) {
		File file = dr;
		if (file.isDirectory()) {
			System.out.println("[" + file.getName() + "]");
			for (File f : file.listFiles()) {
				listAllFiles(f, " ");
			}
		} else {
			System.out.println(file.getName());
		}

	}

	public static void listAllFiles(File dr, String spaces) {
		File file = dr;
		if (file.isDirectory()) {
			System.out.println(spaces + "[" + file.getName() + "]");
			for (File f : file.listFiles()) {
				listAllFiles(f, spaces + " ");
			}
		} else {
			System.out.println(spaces + file.getName());
		}
	}

}
