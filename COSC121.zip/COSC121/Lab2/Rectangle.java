/*Q2
 * For the Rectangle class, I added the extra attributes width and height with the appropriate getters and setters.
 * I modified the toString method, the get Perimeter method, and the getArea method. compareTo and clone() remained the same.
 */

package A2;

public class Rectangle extends Shape implements Comparable<Shape>, Cloneable{
	//attributes
	private double width;
	private double height;
	//constructors
	public Rectangle() {super();}
	public Rectangle(String color, boolean filled, double width, double height) {
		super(color, filled);
		this.setHeight(height);
		this.setWidth(width);
	}
	//methods
	public int compareTo(Shape shp) {
		if(this.getArea() > shp.getArea())
			return 1;
		if(this.getArea() < shp.getArea())
			return -1;
		return 0;
	}
	public double getArea() {return this.getWidth()*this.getHeight();}
	public double getPerimeter() {return (2*this.getHeight()) + (2*this.getWidth());}
	public double getWidth() {return width;}
	public void setWidth(double width) {this.width = width;}
	public double getHeight() {return height;}
	public void setHeight(double height) {this.height = height;}
	public String toString() {
		return "Color: " + this.getColor() + ". " + (this.isFilled()? "Filled. ":"Not filled. ") + "Width: " + this.getWidth() + ". " + "Height: " + this.getHeight() + ". " + "Area: " + this.getArea() + ". " + this.getPerimeter();
	}
	public Object clone() throws CloneNotSupportedException{
		try {
			return super.clone();
		}
		catch(CloneNotSupportedException ex) {
			return null;
		}
	}
}
