/*Q1: For this problem, I used the concrete type Shape in the Comparable interface to avoid some unnecessary casting later on. 
 * For the compareTo method, I set it up to input -1, 1, and 0 to be evaluated in the testing class at a later date
 * I created the appropriate getters and setters for all attributes, and overrode the toString method to display all attributes of a Hexagon.
*/
package A2;

public class Hexagon extends Shape implements Comparable<Shape>, Cloneable{
	//attributes
	private double sideLength;
	//constructors
	public Hexagon() { super(); }
	public Hexagon (String color, boolean filled, double sideLength) {
		super(color, filled);
		this.setSideLength(sideLength);
	}
	//methods
	public int compareTo(Shape shp) {
		if(this.getArea() > shp.getArea())
			return 1;
		if(this.getArea() < shp.getArea())
			return -1;
		return 0;
	}
	public double getArea() { return ((3*Math.sqrt(3))/2)*(this.getSideLength()*this.getSideLength()); }
	public double getPerimeter() { return 6*this.getSideLength(); }
	public double getSideLength() { return sideLength; }
	public void setSideLength(double sideLength) { this.sideLength = sideLength; }
	public String toString(){
		return "Color: " + this.getColor() + ". " + (this.isFilled()? "Filled. ":"Not filled. ") + "Side Length: " + this.getSideLength() + ". " + "Perimeter: " + this.getPerimeter() + ". " + "Area: " + this.getArea();
	}
	public Object clone() throws CloneNotSupportedException{
		try {
			return super.clone();
		}
		catch(CloneNotSupportedException ex) {
			return null;
		}
	}
}
