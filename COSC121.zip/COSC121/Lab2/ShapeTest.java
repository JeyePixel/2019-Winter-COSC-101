/*Q3: I manually added objects to the array without an advanced for-loop. I didn't make a way for random colors to be generated.
 * FOr the total area of the shape array, I created an advanced for loop to iterate over every Shape in shapes and add the area to totalArea.
 * It turns out, you can call the clone method on an array. That made my job a lot easier.
 * Because we compared objects using the area, I was able to use the Arrays class to sort all SHapes in the cloned Shape array.
 * Finally, I used an advanced for-loop and formatted print statements to display the areas in both arrays.
 *
 */

package A2;

import java.util.Arrays;

public class ShapeTest {

	public static void main(String[] args) throws CloneNotSupportedException{
		Shape[] shapes = new Shape[5];
		shapes[0] = new Hexagon("Green", true, 5);
		shapes[1] = new Hexagon("Blue", false, 8);
		shapes[2] = new Hexagon("Yellow", true, 6);
		shapes[3] = new Rectangle("Green", true, 5, 5);
		shapes[4] = new Rectangle("Green", true, 5, 7);
		
		double totalArea = 0;
		for(Shape element: shapes) {
			totalArea+=element.getArea();
		}
		System.out.println("the total area of all shapes in the shapes array is " + totalArea);
		
		Shape[] shapes2 = shapes.clone();
		System.out.println("shapes has been cloned to shapes2");
		
		Arrays.sort(shapes2);
		System.out.println("shapes2 has been sorted");
		
		System.out.printf("%-30s %s", "The areas inside shapes", "the areas inside shapes2\n");
		for(int i=0; i <= shapes.length -1; i++) {
			System.out.printf("%-30f %f", shapes[i].getArea(), shapes2[i].getArea());
			System.out.println();
		}
	}

}
