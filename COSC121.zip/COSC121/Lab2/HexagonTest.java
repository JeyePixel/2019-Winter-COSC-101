/*Q1 CONTINUED: Using a Scanner object to read data in from the keyboard, I created a constructor that allowed a user to make a custom Hexagon. 
 * Using the clone() command found in the Hexagon class, I cloned the hexagon and used the compareTo() method to compare areas.
 * I also added a CloneNotSupported exception to the main method.
*/
package A2;

import java.util.Scanner;

public class HexagonTest {
	
	public static void main(String[] args) throws CloneNotSupportedException{
		Scanner in = new Scanner(System.in);
		System.out.println("Color? ");
		String color = in.next();
		System.out.println("Filled? ");
		boolean filled = in.nextBoolean();
		System.out.println("Length? ");
		double length = in.nextDouble();
		Hexagon hexagon = new Hexagon(color, filled, length);
		System.out.println(hexagon.toString());
		
		Hexagon hexagon2 = (Hexagon) hexagon.clone();
		
		if(hexagon.compareTo(hexagon2) > 0) {
			System.out.println("Hexagon 1 is larger");
		}
		if(hexagon.compareTo(hexagon2) < 0) {
			System.out.println("Hexagon 2 is larger");
		}
		if(hexagon.compareTo(hexagon2) == 0) {
			System.out.println("Both hexagons are identical");
		}
	}

}
