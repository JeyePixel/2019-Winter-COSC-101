package A2;

import java.util.Scanner;

public class RectangleTest {

	public static void main(String[] args) throws CloneNotSupportedException{
		Scanner in = new Scanner(System.in);
		System.out.println("Color? ");
		String color = in.next();
		System.out.println("Filled? ");
		boolean filled = in.nextBoolean();
		System.out.println("Width? ");
		double width = in.nextDouble();
		System.out.println("Height? ");
		double height = in.nextDouble();
		Rectangle rectangle = new Rectangle(color, filled, width, height);
		System.out.println(rectangle.toString());
		
		Rectangle rectangle2 = (Rectangle) rectangle.clone();
		
		if(rectangle.compareTo(rectangle2) > 0) {
			System.out.println("Rectangle 1 is larger");
		}
		if(rectangle.compareTo(rectangle2) < 0) {
			System.out.println("Rectangle 2 is larger");
		}
		if(rectangle.compareTo(rectangle2) == 0) {
			System.out.println("Both rectangles are identical");
		}

	}

}
