/*
 * To read in bytes, I started with the backup() method. It would take in a filename and number of bytes to read.
 * This program is assuming the user is entering in MB values and converting them into bytes. 
 * After 25000000 bytes have been read into a byte array, I iterate through the elements in an array and write them to a new file.
 */

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Q3 {

	public static void main(String[] args) {
//		System.out.println("Attempting to backup the syllabus");
//		System.out.println(backup("syllabus.pdf", 0.25));
//		System.out.println("Done!");
		System.out.println("Attempting to restore the syllabus");
		restore("syllabus.pdf", 4);
	}

	public static int backup(String filename, double partSize) {
		File file = new File(filename);
		try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {
			int amountOfBytes = (int) (1000000 * partSize);
			int fileNumber = 0;
			int bytesAmount = 0;
			String newName = filename.replace(".pdf", "");
			byte[] buffer = new byte[amountOfBytes];
			while ((bytesAmount = in.read(buffer)) > 0) {
				fileNumber++;
				String filePartName = String.format("%s.%03d" + ".pdf", newName, fileNumber);
				File newFile = new File(file.getParent(), filePartName);
				try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(newFile))) {
					out.write(buffer, 0, bytesAmount);
				}
			}
			return fileNumber;
		} catch (IOException e) {
			System.out.println("Error: Could not read bytes from file!");
			return -1;
		}
	}

	public static int restore(String filename, int numberOfPieces) {
		try {
			String removePDF = filename.replace(".pdf", "");
			String splitFileNames;
			BufferedInputStream in;
			BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(new File(filename)));
			for (int i = 1; i <= numberOfPieces; i++) {
				splitFileNames = removePDF + ".00" + i + ".pdf";
				in = new BufferedInputStream(new FileInputStream(new File(splitFileNames)));
				//System.out.println("Found file " + i);
			}

			return -1;
		} catch (IOException e) {
			System.out.println("Error: Could not perform I/O operations!");
			return -1;
		}
	}
}
