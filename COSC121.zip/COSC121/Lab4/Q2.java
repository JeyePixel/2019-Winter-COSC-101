/*
 * In the method viewHex, i attached a file input stream to the data.dat file
 * Using if/else statements and printf, I formatted the bytes after translating them from integers to hexstrings.
 * As predicted, it made a table of all values in data.dat`
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class Q2 {

	public static void main(String[] args) throws IOException {
		viewHex("data.dat");

	}

	public static void viewHex(String filename) {
		File file = new File(filename);
		int i = 0;
		int byteDisplay = 0;
		try {
			FileInputStream in = new FileInputStream(file);
			while (in.available() > 0) {
				if (i == 8) {
					System.out.printf("%c\t", '|');
					i++;
				}else if(i == 17) {
					byteDisplay = in.read();
					System.out.printf("%s\n", Integer.toHexString(byteDisplay));
					i = 0;
				}else {
					byteDisplay = in.read();
					System.out.printf("%s\t", Integer.toHexString(byteDisplay));
					i++;
				}
			}
		} catch (IOException e) {
			System.out.println("Error: Could not read from file!");
		}

	}

}