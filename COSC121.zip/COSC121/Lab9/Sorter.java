package A9;

import java.util.ArrayList;
import java.util.Comparator;

public class Sorter {

	public static void bubbleSort(ArrayList<Patient> list) {
		boolean sorted = false;
		for (int i = 1; i <= list.size() - 1 && !sorted; i++) {
			sorted = true;
			if (list.get(i - 1).compareTo(list.get(i)) == -1)
				sorted = false;
			else if (list.get(i - 1).compareTo(list.get(i)) == 1) {
				Patient temp = list.get(i - 1);
				list.set(i - 1, list.get(i));
				list.set(i, temp);
				sorted = false;
			} else if (list.get(i - 1).compareTo(list.get(i)) > 0)
				sorted = false;
			else if (list.get(i - 1).compareTo(list.get(i)) < 0) {
				Patient temp = list.get(i - 1);
				list.set(i - 1, list.get(i));
				list.set(i, temp);
				sorted = false;
			}
		}
	}

	public static void bubbleSort(ArrayList<Patient> list, Comparator<Patient> comparator) {

	}

	public static void selectionSort(ArrayList<Patient> list) {
		for (int index = 0; index < list.size(); index++) {
			int minIndex = index;
			for (int scan = index + 1; scan < list.size(); scan++) {
				if( list.get(scan).compareTo(list.get(minIndex)) == 1)
					minIndex = scan;
				else if( list.get(scan).compareTo(list.get(minIndex)) < 0) {
					minIndex = scan;
				}
				
			}
		}

	}

	public static void insertionSort(ArrayList<Patient> list) {

	}
}
