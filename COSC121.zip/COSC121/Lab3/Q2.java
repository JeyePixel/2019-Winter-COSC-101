package A3;
/*
 * Q2 uses a switch statement to check the String that holds our operator.
 * An integer is checked for our loop.
 * As long as invalid inputs are made, the loop will continue.
 */

import java.util.InputMismatchException;
import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) throws InputMismatchException {

		// Attributes
		Scanner in;
		int flag = 0;

		while (flag != -1) {
			System.out.println("Please enter a a simple mathematical formula: ");
			try {
				in = new Scanner(System.in);
				double firstnum = in.nextDouble();
				String operator = in.next();
				double lastnum = in.nextDouble();
				System.out.println();
				switch (operator) {
				case "+":
					System.out.println("The answer is: " + (firstnum + lastnum));
					break;
				case "-":
					System.out.println("The answer is: " + (firstnum - lastnum));
					break;
				case "/":
					System.out.println("The answer is: " + (firstnum / lastnum));
					break;
				case "*":
					System.out.println("The answer is: " + (firstnum * lastnum));
					break;
				default:
					break;
				}

				flag = -1;
			} catch (InputMismatchException e) {
				System.out.println("Invalid operator: try again");
			}
		}
	}

}