package A3;

/*
 * The main difference with Q3 and Q2 is that now that we are trying to use Double.parseDouble(),
 * We can encounter the NumberFormatException. This is caused when we format a non-number value.
 * We can deal with this by throwing both NumberFormatException and InputMismatchException. 
 * Alternatively, we can just throw Exception.
 */
import java.util.InputMismatchException;
import java.util.Scanner;

public class Q3 {

	public static void main(String[] args) throws Exception {

		// Attributes
		Scanner in;
		int flag = 0;

		while (flag != -1) {
			System.out.println("Please enter a a simple mathematical formula: ");
			try {
				in = new Scanner(System.in);
				String firstnum = in.next();
				double firstNumDouble = Double.parseDouble(firstnum);
				String operator = in.next();
				String lastnum = in.next();
				double lastNumDouble = Double.parseDouble(lastnum);
				System.out.println();
				switch (operator) {
				case "+":
					System.out.println("The answer is: " + (firstNumDouble + lastNumDouble));
					break;
				case "-":
					System.out.println("The answer is: " + (firstNumDouble - lastNumDouble));
					break;
				case "/":
					System.out.println("The answer is: " + (firstNumDouble / lastNumDouble));
					break;
				case "*":
					System.out.println("The answer is: " + (firstNumDouble * lastNumDouble));
					break;
				default:
					break;
				}

				flag = -1;
			} catch (InputMismatchException e) {
				System.out.println("Invalid operator: try again");
			} catch (NumberFormatException e) {
				System.out.println("Invalid number: try again");
			}
		}
	}
}