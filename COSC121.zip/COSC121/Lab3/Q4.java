package A3;
/*
 * For the replaceCensoredWords method, I saved the line as a single string.
 * Using String.replace, I iterated through the elements of my censoredWords array.
 * After replacing all censored words in the String, it returns it.
 * For the file reading portion, I used a Scanner for the input stream and a PrintWriter for the output stream.
 * While the Scanner had a next line, I would call the replaceCensoredWords method.
 * After, I wrote the returned censored string to the specified file.
 */

import java.io.*;
import java.util.*;

public class Q4 {

	public static void main(String[] args) throws Exception {
		String censoredWords[] = { "ABC", "XYZ" };
		File sourceFile = new File("C:\\Users\\40183402\\Desktop\\test\\source.txt");
		File destinationFile = new File("C:\\Users\\40183402\\Desktop\\test\\destination.txt");
		Scanner input = new Scanner(sourceFile);
		PrintWriter output = new PrintWriter(destinationFile);
		while (input.hasNextLine()) {
			String testline = input.nextLine().toUpperCase();
			output.write(replaceCensoredWords(testline.toUpperCase(), censoredWords));
			output.println();
		}
		input.close();
		output.close();
	}

	private static String replaceCensoredWords(String line, String[] censoredWords) {
		Scanner input = new Scanner(line);
		String censoredString = input.nextLine();
		for (int i = 0; i < censoredWords.length; i++) {
			if (censoredString.contains(censoredWords[i])) {
				censoredString = censoredString.replace(censoredWords[i], "...");
			}
		}
		input.close();
		return censoredString;
	}

}