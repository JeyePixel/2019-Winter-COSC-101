package A3;

/*
 * For Q1, I put the code that actually indexes the array inside of a try block.
 * The corresponding catch block will print an error and keep the user inside the loop.
 * Only when a correct index is entered will the loop break.
 */

import java.util.Random;
import java.util.Scanner;

public class Q1Exception {

	public static void main(String[] args) throws IndexOutOfBoundsException{

		// Attributes
		boolean checker = false;
		Scanner in = new Scanner(System.in);
		Random rand = new Random();
		int[] intArray = new int[100];
		for (int i = 0; i < intArray.length; i++) {
			intArray[i] = rand.nextInt();
		}

		while (!checker) {
			System.out.println("Please enter an index of the array: ");
			int index = in.nextInt();
			try{
				System.out.println("The value at " + index + " is " + intArray[index]);
				checker = true;
			} catch(IndexOutOfBoundsException e){
				System.out.println("That is not a valid index!");
			}
		}

	}

}