/*\
 * To create a doubly linked list, I gave the Node class another attribute; previous.
 * Then, I changed all the adding, removing, setting, and getting methods to manipulate
 * the 'previous' pointer when dealing with nodes. To improve performance with getting nodes,
 * I used logic statements to determine if it was faster to iterate through the list 
 * using the 'next' pointers or the 'previous' pointers. 
 */

package A8;

public class MyDoublyLinkedList<E> {
	private int size;
	private Node<E> head, tail;

	// Constructors
	public MyDoublyLinkedList() {
		head = tail = null;
	}

	public MyDoublyLinkedList(E[] objects) {
		for (int i = 0; i < objects.length; i++)
			add(objects[i]);
	}

	// Methods

	// *** ADDING ***
	public void add(E e) {
		addLast(e);
	}

	public void addFirst(E e) {
		Node<E> newNode = new Node<E>(e); // Create a new node
		if (tail == null) // if empty list
			head = tail = newNode; // new node is the only node in list
		else {
			newNode.next = head; // link the new node with the head
			newNode.previous = null;
			head.previous = newNode;
			head = newNode; // head points to the new node
		}
		size++;
	}

	public void addLast(E e) {
		Node<E> newNode = new Node<E>(e); // Create a new for element e
		if (tail == null) // if empty list
			head = tail = newNode; // new node is the only node in list
		else {
			newNode.previous = tail;
			newNode.next = null;
			tail.next = newNode; // Link the new with the last node
			tail = tail.next; // tail now points to the last node
		}
		size++;
	}

	public void add(int index, E e) {
		if (index < 0 || index > size)
			throw new IndexOutOfBoundsException(); // according to Java doc.
		else if (index == 0)
			addFirst(e);
		else if (index == size)
			addLast(e);
		else {
			Node<E> newNode = new Node<E>(e);
			Node<E> current = this.getNodeAt(index);
//			Node<E> newNode = new Node<E>(e);
//			Node<E> current = head; // ]
//			for (int i = 1; i < index; i++) // ]- get a reference to index-1
//				current = current.next; // ]
			newNode.previous = current.previous;// Link the new node to element @ index
			current.previous.next = newNode;
			newNode.next = current;
			current.previous = newNode;
			size++;
		}
	}

	// *** REMOVING ***
	public E removeFirst() {
		if (size == 0)
			return null;
		else {
			Node<E> temp = head; // element will be returned
			head = head.next;
			head.previous = null;
			size--;
			if (head == null) // if list becomes empty
				tail = null;
			return temp.element; // return the removed element
		}
	}

	public E removeLast() {
		if (size == 0)
			return null;
		else if (size == 1) {
			Node<E> temp = head;
			head = tail = null;
			size = 0;
			return temp.element;
		} else {
			Node<E> temp = tail; // to return it
//			E element = temp.element;
			Node<E> current = tail.previous;
			tail = current;
			tail.next = null; // remove last
			size--;
			return temp.element; // return last
		}
	}

	public E remove(int index) {
		if (index < 0 || index >= size)
			return null;
		else if (index == 0)
			return removeFirst();
		else if (index == size - 1)
			return removeLast();
		else {
			Node<E> current = this.getNodeAt(index);
			current.previous.next = current.next;
			current.next.previous = current.previous;
			current.next = null;
			current.previous = null;
			size--;
			return current.element;
		}
	}

	public boolean remove(E e) {
		if (indexOf(e) >= 0) { // if the element exists
			remove(indexOf(e)); // call the other remove method
			return true;
		} else
			return false;
	}

	public void clear() {
		size = 0;
		head = tail = null;
	}

	// *** GETTING ***
	public E getFirst() {
		if (size == 0)
			return null;
		else
			return head.element;
	}

	public E getLast() {
		if (size == 0)
			return null;
		else
			return tail.element;
	}

	public E get(int index) {
		if (index < 0 || index > size - 1)
			return null;
		else if (index == 0)
			return getFirst();
		else if (index == size - 1)
			return getLast();
		else {
			Node<E> current = this.getNodeAt(index);
			return current.element;
		}
	}

	// *** SETTING ***
	public E set(int index, E e) {
		if (index < 0 || index > size - 1)
			return null;
		Node<E> current = this.getNodeAt(index);
		E temp = current.element;
		current.element = e;
		return temp;
	}

	// *** TOSTRING ***
	public String toString() {
		StringBuilder result = new StringBuilder("[");
		Node<E> current = head;
		for (int i = 0; i < size; i++) {
//			System.out.println(current.element);
			result.append(current.element);
			current = current.next;
			if (current != null)
				result.append(", "); // Separate two elements with a comma
			else
				result.append("]"); // Insert the closing ] in the string
		}
		return result.toString();
	}

	public String toReversedString() {
		StringBuilder result = new StringBuilder("[");
		Node<E> current = tail;
		for (int i = 0; i < size; i++) {
			result.append(current.element);
			current = current.previous;
			if (current != null)
				result.append(", "); // Separate two elements with a comma
			else
				result.append("]"); // Insert the closing ] in the string
		}
		return result.toString();
	}

	// *** CHECKING ***
	public int size() {
		return size;
	}

	public boolean contains(E e) {
		Node<E> current = head;
		for (int i = 0; i < size; i++) {
			if (current.element.equals(e))
				return true;
			current = current.next;
		}
		return false;
	}

	public int indexOf(E e) {
		Node<E> current = head;
		for (int i = 0; i < size; i++) {
			if (current.element.equals(e))
				return i;
			current = current.next;
		}
		return -1;
	}

	public int lastIndexOf(E e) { /** improve performance using 'previous' [3 marks] */
		int lastIndex = -1;
		Node<E> current = head;
		for (int i = 0; i < size; i++) {
			if (current.element.equals(e))
				lastIndex = i;
			current = current.next;
		}
		return lastIndex;
	}

	// *** HELPER METHODS ***
	private void checkIndex(int idx) {
		if (idx < 0 || idx >= size)
			throw new IndexOutOfBoundsException("Index: " + idx + ", Size: " + size);
	}

	private Node<E> getNodeAt(int index) {
		if (index < 0 || index > size - 1)
			return null;
		if (index < size / 2) {
			Node<E> current = head;
			for (int i = 0; i < index; i++)
				current = current.next;
			return current;
		} else {
			Node<E> current = tail;
			for (int i = size - 1; i > index; i--)
				current = current.previous;
			return current;
		}
	}

	// *** INNER NODE CLASS ***
	private static class Node<E> {
		E element;
		Node<E> next;
		Node<E> previous;

		public Node(E e) {
			element = e;
		}
	}
}